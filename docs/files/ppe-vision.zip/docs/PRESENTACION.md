# Presentación: detección de EPP con visión artificial

> Estructura para completar (≈ 15 min + preguntas). Cada diapositiva indica **mensaje**, **contenido a llenar**,
> **visual** (ruta del archivo) y **notas del orador**. Una idea por diapositiva; los números salen de los JSON indicados.

| # | Diapositiva | Min |
|---|---|---|
| 1 | Portada | 0.5 |
| 2 | Problema y objetivo | 1 |
| 3 | Datos y hallazgos del EDA | 1.5 |
| 4 | Preparación: particiones y aumentos | 1 |
| 5 | Modelo y entrenamiento | 1.5 |
| 6 | Desempeño offline del modelo | 1.5 |
| 7 | Pipeline de inferencia (y resoluciones distintas) | 1.5 |
| 8 | Reglas de negocio | 1.5 |
| 9 | Persistencia y trazabilidad | 1 |
| 10 | Desempeño de las predicciones | 1.5 |
| 11 | Desempeño de los eventos | 1.5 |
| 12 | Monitoreo operacional (MLOps) | 1 |
| 13 | Errores y causas | 1 |
| 14 | Nuevo ciclo, limitaciones y siguientes pasos | 1 |
| 15 | Conclusiones | 0.5 |

---

## 1. Portada
- **Título:** Detección de condiciones inseguras de EPP con visión artificial
- Nombre, fecha, versión del modelo (`1.0.0`).

## 2. Problema y objetivo
- **Mensaje:** detectar personas sin casco/chaleco en áreas operativas y convertirlo en eventos accionables.
- **Contenido:** contexto en 2 líneas; entradas (imágenes/video + ROI) y salidas (`predictions.jsonl`, `events.jsonl`, `metrics.json`); criterio de éxito: _<métrica objetivo>_.
- **Visual:** diagrama de una línea: imagen → detector → reglas → evento.
- **Notas:** por qué no basta con un modelo preentrenado.

## 3. Datos y hallazgos del EDA
- **Mensaje:** el dataset determina lo que el modelo puede aprender.
- **Contenido:** fuente (Kaggle), 5 clases, imágenes por partición, objetos por clase, desbalance (_<razón>_), resoluciones, % de objetos pequeños, problemas encontrados (corruptas, duplicados, fuga: _<n>_).
- **Visual:** `reports/eda/objects_per_class.png`, `reports/eda/samples_with_boxes.png`.
- **Fuente de números:** `reports/eda/dataset_report.json`.

## 4. Preparación: particiones y aumentos
- **Contenido:** cómo se evitó la fuga (agrupar por imagen fuente); tabla de aumentos con su justificación (sin volteo vertical, HSV para iluminación, mosaic para objetos pequeños).
- **Visual:** tabla de `configs/train.yaml → augment`; ejemplo antes/después.

## 5. Modelo y entrenamiento
- **Contenido:** YOLOv8n desde COCO; `imgsz`, épocas, batch, optimizador, LR, semilla, hardware, tiempo; criterio del mejor checkpoint (fitness); trazabilidad (MLflow / `model_metadata.json`).
- **Visual:** curva de pérdidas/mAP (`runs/train/<name>/results.png`).
- **Fuente:** `models/model_metadata.json`.

## 6. Desempeño offline del modelo
- **Mensaje:** el modelo detecta bien _<clases>_ y tiene dificultades con _<clases>_.
- **Contenido:** P/R/F1 global y por clase, mAP@0.5 y mAP@0.5:0.95, FPS e ms/imagen.
- **Visual:** `reports/offline/confusion_matrix.png`, `reports/offline/precision_recall_curve.png`.
- **Fuente:** `reports/offline/metrics.json`.

## 7. Pipeline de inferencia
- **Mensaje:** robusto ante archivos malos y resoluciones distintas.
- **Contenido:** flujo (validar → letterbox → detectar → volver a coordenadas originales → umbrales/NMS → reglas → JSONL); un archivo fallido no detiene el lote; comparación `letterbox` vs `resize` vs `none` (tabla del reporte, sección 5.1).
- **Visual:** diagrama del flujo; imagen original con bordes (letterbox) y detecciones mapeadas de vuelta.
- **Notas:** por qué letterbox no deforma personas.

## 8. Reglas de negocio
- **Contenido:** tabla condición → evento → severidad; asociación por zonas del cuerpo; ROI por los pies; persistencia temporal; duplicados (cooldown, fusión de track); estrategia `association` / `explicit` / `hybrid`.
- **Visual:** `outputs/latest/annotated/...` con ROI, persona en rojo y etiqueta del evento.
- **Fuente:** `configs/rules.yaml`, `docs/DECISIONS.md`.

## 9. Persistencia y trazabilidad
- **Contenido:** ejemplo de una línea de `predictions.jsonl` y de `events.jsonl`; versionado (`schema_version`, `model_version`, `run_id`); cómo se enlaza evento ↔ predicción.
- **Visual:** fragmento JSON.

## 10. Desempeño de las predicciones
- **Mensaje:** el sistema, medido contra verdad terreno revisada, alcanza _<F1>_.
- **Contenido:** tamaño y selección del ground truth (_<n imágenes, cómo>_), TP/FP/FN por clase, P/R/F1, mAP, imágenes sin detecciones y anotaciones sin predicción.
- **Visual:** `reports/evaluation/confusion_matrix_predictions.png`, `pr_curve_predictions.png`.
- **Fuente:** `reports/evaluation/prediction_metrics.json`.

## 11. Desempeño de los eventos
- **Contenido:** P/R/F1 de eventos; duplicados y tasa de duplicidad; omitidos; latencia condición → evento; resultados por cámara/fuente/tipo; comparación de estrategias de decisión.
- **Visual:** tabla de estrategias (reporte 6.2); barras por tipo de evento.
- **Fuente:** `reports/evaluation/event_metrics.json`.

## 12. Monitoreo operacional (MLOps)
- **Contenido:** volumen (archivos, frames, detecciones, eventos), rendimiento (ms/frame, FPS, fallidos), calidad (confianza por clase, descartes), segmentación, trazabilidad (modelo, hash de config, semilla, fecha).
- **Visual:** panel con 6–8 indicadores de `outputs/latest/metrics.json`.

## 13. Errores y causas
- **Contenido:** 3–4 ejemplos comentados (FP y FN) con su causa probable (objeto pequeño, oclusión, confusión de clase, duplicado, fondo) y la mejora propuesta.
- **Visual:** `reports/evaluation/error_examples/*.jpg`.
- **Fuente:** `reports/evaluation/errors.jsonl`.

## 14. Nuevo ciclo, limitaciones y siguientes pasos
- **Contenido:** muestras seleccionadas (baja confianza, errores, sin detección, control de calidad; estratificadas por cámara/clase) → reetiquetado → reentrenamiento; limitaciones (ground truth pequeño, sesgo de dominio, ground truth de eventos derivado); próximos pasos (más datos, ByteTrack, calibración de umbrales, monitoreo de deriva).
- **Fuente:** `reports/next_cycle_samples.csv`.

## 15. Conclusiones
- 3 mensajes: qué funciona, qué falla y qué sigue. Cierre con demo breve (comando de inferencia y evento generado).

---

### Apéndice: de dónde sale cada número

| Número | Archivo | Campo |
|---|---|---|
| Imágenes y objetos por clase | `reports/eda/dataset_report.json` | `splits.*`, `imbalance` |
| mAP, P/R/F1 del modelo, FPS | `reports/offline/metrics.json` | `splits.test.global`, `fps_inference_only` |
| TP/FP/FN, mAP de predicciones | `reports/evaluation/prediction_metrics.json` | `per_class`, `global` |
| P/R/F1 de eventos, duplicados, latencia | `reports/evaluation/event_metrics.json` | `overall`, `duplicate_rate`, `latency_seconds` |
| Volumen, FPS, calidad | `outputs/latest/metrics.json` | `volume`, `performance`, `quality` |
| Trazabilidad | `models/model_metadata.json` | `training`, `hardware`, `dataset` |
