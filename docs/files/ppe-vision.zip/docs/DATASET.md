# Dataset

## Procedencia

| Campo | Valor |
|---|---|
| Nombre | Personal Protective Equipment (PPE) Dataset |
| Autor / fuente | `ndomalau` en Kaggle |
| URL | https://www.kaggle.com/datasets/ndomalau/personal-protective-equipment-ppe-dataset |
| Descarga | `kaggle datasets download -d ndomalau/personal-protective-equipment-ppe-dataset -p src/data/kaggle_dataset --unzip` |
| Licencia | _<verificar en la página de Kaggle y anotar aquí>_ |
| Fecha de descarga | _<completar>_ |
| Formato | YOLO (`images/` + `labels/` por partición, `data.yaml`) |

## Clases

`['helmet', 'no_helmet', 'no_vest', 'person', 'vest']` (nc = 5). Las clases `no_helmet` y `no_vest` son
ausencias anotadas explícitamente; la clase `person` es la que se evalúa contra el ROI.

## Estructura esperada

```
src/data/kaggle_dataset/
├── data.yaml
├── train/{images,labels}
├── valid/{images,labels}
└── test/{images,labels}
```

Las rutas `../train/images` del `data.yaml` no resuelven desde esa carpeta; los scripts buscan automáticamente
`<partición>/images`.

## Hallazgos del EDA

_<Completar con `reports/eda/dataset_report.json`: imágenes por partición, objetos por clase, desbalance,
resoluciones, duplicados/fuga entre particiones, objetos pequeños, problemas de etiquetas.>_

## Videos e insumos adicionales

| Insumo | Estado |
|---|---|
| Imágenes para inferencia | partición `test/` del dataset (y/o imágenes propias en otra resolución) |
| ROI | polígonos en `configs/rules.yaml` (definir para la escena real) |
| Subconjunto etiquetado | `data/ground_truth/` generado con `scripts/build_ground_truth.py` |

## Limitaciones

- _<Cámaras/escenas representadas, iluminación, ángulos, número de personas por imagen.>_
- _<Sesgo de dominio frente a las cámaras de producción.>_
- La verdad terreno de eventos derivada de anotaciones no es una revisión humana independiente.
