# Detección de EPP con visión artificial (casco y chaleco)

Solución de punta a punta: validación de datos → entrenamiento de YOLOv8n → inferencia sobre carpetas de
imágenes → reglas de negocio (ROI, asociación persona↔EPP, persistencia, duplicados, severidad) →
persistencia en JSONL → evaluación de predicciones y eventos → monitoreo y selección de muestras.

- Reporte técnico (para completar): [`docs/REPORTE.md`](docs/REPORTE.md)
- Presentación (para completar): [`docs/PRESENTACION.md`](docs/PRESENTACION.md)
- Decisiones técnicas y reglas de negocio: [`docs/DECISIONS.md`](docs/DECISIONS.md)
- Dataset (procedencia, clases, limitaciones): [`docs/DATASET.md`](docs/DATASET.md)
- Parámetros de configuración: [`configs/README.md`](configs/README.md)

## 1. Estructura

```
.
├── configs/
│   ├── train.yaml          # entrenamiento (hiperparámetros, aumentos, rutas)
│   ├── inference.yaml      # modelo, umbrales, resolución, modo de entrada, salidas
│   └── rules.yaml          # ROI, asociación, persistencia, severidad, estrategia de decisión
├── scripts/                # puntos de entrada (CLI)
│   ├── eda.py                    # validación + EDA del dataset
│   ├── train.py                  # fine-tuning YOLOv8n + metadata + métricas offline
│   ├── inference.py              # pipeline de inferencia sobre una carpeta de imágenes
│   ├── build_ground_truth.py     # etiquetas YOLO -> ground_truth.jsonl (+ eventos esperados)
│   ├── evaluate_predictions.py   # predicciones y eventos vs verdad terreno
│   ├── select_samples.py         # muestras para el nuevo ciclo
│   └── package_delivery.py       # empaqueta la entrega en .zip (por partes)
├── src/ppe/                # código reutilizable
│   ├── data/dataset.py           # lectura del dataset YOLO, hashes, etiquetas
│   ├── inference/                # preprocess (letterbox), detector, postprocess (umbrales, NMS)
│   ├── rules/                    # geometry, roi, association, tracker, events
│   ├── persistence/writers.py    # escritura JSONL
│   ├── monitoring/metrics.py     # metrics.json operacional
│   ├── evaluation/               # detection.py (P/R/F1/mAP/errores), events.py
│   └── pipeline.py               # orquesta todo el flujo de inferencia
├── tests/                  # pruebas unitarias (ROI, asociación, duplicados, reglas, resolución, evaluación)
├── notebooks/              # 5 notebooks de análisis + helpers.py
├── docs/                   # reporte, presentación, decisiones, dataset
├── src/data/kaggle_dataset/  # dataset (train/ valid/ test/ + data.yaml)
├── models/                 # best_model.pt, model_metadata.json          (se genera)
├── reports/                # eda/, offline/, evaluation/                  (se genera)
└── outputs/                # <run_id>/ y latest/ con las predicciones     (se genera)
```

## 2. Instalación

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

Python 3.10+. Se recomienda GPU para entrenar; la inferencia funciona en CPU.

## 3. Flujo de trabajo (todo desde la raíz del repositorio)

```bash
# 1) Validación y EDA del dataset  ->  reports/eda/dataset_report.json + figuras
python scripts/eda.py --root src/data/kaggle_dataset --out reports/eda

# 2) Entrenamiento  ->  models/best_model.pt, models/model_metadata.json, reports/offline/*
python scripts/train.py --config configs/train.yaml
#    prueba rápida:  --set train.epochs=2 train.batch=8      validar datos sin entrenar:  --dry-run

# 3) Inferencia sobre una carpeta de imágenes  ->  outputs/<run_id>/ y outputs/latest/
python scripts/inference.py --source src/data/kaggle_dataset/test/images
#    imágenes con otra resolución:  --resize-mode letterbox (por defecto) | resize | none
#    secuencia de frames de una cámara:  --mode sequence --fps 5 --camera-id CAM_01
#    imágenes anotadas como evidencia:   --save-annotated

# 4) Verdad terreno  ->  data/ground_truth/ground_truth.jsonl (+ ground_truth_events.jsonl)
python scripts/build_ground_truth.py --split-dir src/data/kaggle_dataset/test --out data/ground_truth --derive-events

# 5) Desempeño de predicciones y eventos  ->  reports/evaluation/
python scripts/evaluate_predictions.py \
    --predictions outputs/latest/predictions.jsonl --ground-truth data/ground_truth/ground_truth.jsonl \
    --events outputs/latest/events.jsonl --ground-truth-events data/ground_truth/ground_truth_events.jsonl \
    --images-index outputs/latest/images_index.jsonl --out reports/evaluation

# 6) Muestras para el nuevo ciclo  ->  reports/next_cycle_samples.csv
python scripts/select_samples.py --run outputs/latest --errors reports/evaluation/errors.jsonl --n 100

# 7) Pruebas unitarias
python -m pytest -q

# 8) Empaquetar la entrega (partes <= 20 MB)
python scripts/package_delivery.py --out entrega --max-mb 20
```

> **Para medir mAP completo**, ejecuta la inferencia del paso 3 con un umbral bajo
> (`--conf 0.001`) y evalúa con el punto de operación real: `--conf 0.25` en el paso 5. Con un umbral alto
> al inferir, las curvas PR y el mAP quedan truncados.

### 3.1 Notebooks

Los notebooks no contienen la lógica del pipeline: llaman a los scripts y analizan sus salidas, así que la solución no depende de ejecución manual en ellos.
Ábrelos con `jupyter lab` (desde cualquier carpeta; ajustan solos el directorio de trabajo a la raíz del repo) y ejecuta las celdas en orden.

| Notebook | Contenido | Necesita modelo |
|---|---|---|
| `01_eda.ipynb` | Validación del dataset, desbalance, duplicados/fuga, completitud de anotaciones | no |
| `02_entrenamiento_y_evaluacion_offline.ipynb` | Configuración y curvas de entrenamiento, métricas por clase, FPS, matriz de confusión y curva PR | sí (si `RUN_TRAIN`) |
| `03_inferencia_y_reglas_de_negocio.ipynb` | Letterbox/resize, ROI, estrategias de decisión, persistencia y duplicados (casos sintéticos) e inferencia real | sólo el bloque 3 |
| `04_evaluacion_de_predicciones_y_eventos.ipynb` | Verdad terreno, métricas, causas de error, eventos; experimentos de estrategia y de resolución | sí |
| `05_monitoreo_y_nuevo_ciclo.ipynb` | `metrics.json` operacional y selección de muestras | no (lee una corrida) |

Las rutas se pueden cambiar con variables de entorno `PPE_*` (p. ej. `PPE_RUN_DIR`, `PPE_DATASET_ROOT`) sin editar los notebooks.

## 4. Dónde está cada entregable

| # | Entregable | Ubicación | Se genera con |
|---|---|---|---|
| 0 | Datasets utilizados | `src/data/kaggle_dataset/` y URL en [`docs/DATASET.md`](docs/DATASET.md) | descarga manual (Kaggle) |
| 1 | Código fuente | `src/ppe/`, `scripts/`, `configs/`, `tests/` | — |
| 2 | Notebooks | `notebooks/01…05_*.ipynb` | listos; ejecutan los scripts y analizan sus artefactos (ver sección 3.1) |
| 3 | Modelo | `models/best_model.pt`, `models/model_metadata.json` | `scripts/train.py` |
| 4 | Documentación | `README.md`, `configs/README.md`, `docs/` | completar `docs/REPORTE.md` |
| 5 | Predicciones | `outputs/latest/predictions.jsonl`, `events.jsonl` | `scripts/inference.py` |
| 6 | Evaluación | ver detalle abajo | `train.py`, `evaluate_predictions.py` |
| 7 | Monitoreo | `outputs/latest/metrics.json` | `scripts/inference.py` |

**Evidencias de la evaluación (entregable 6):**

| Evidencia | Archivo |
|---|---|
| `dataset_report.json` + visualizaciones del EDA | `reports/eda/` |
| Métricas offline del modelo (P/R/F1, mAP, FPS) | `reports/offline/metrics.json` |
| Matriz de confusión y curva PR del modelo | `reports/offline/confusion_matrix.png`, `reports/offline/precision_recall_curve.png` |
| Metadatos y trazabilidad del entrenamiento | `models/model_metadata.json`, `runs/train/<name>/` |
| Desempeño de predicciones vs verdad terreno | `reports/evaluation/prediction_metrics.json` |
| Matriz de confusión y curva PR de las predicciones | `reports/evaluation/confusion_matrix_predictions.png`, `pr_curve_predictions.png` |
| Desempeño de eventos (P/R/F1, duplicados, omitidos, latencia) | `reports/evaluation/event_metrics.json` |
| Errores con causa probable y ejemplos visuales | `reports/evaluation/errors.jsonl`, `reports/evaluation/error_examples/` |
| Muestras del nuevo ciclo | `reports/next_cycle_samples.csv` |

> Hay dos `metrics.json` con propósitos distintos: `reports/offline/metrics.json` (evaluación del modelo) y
> `outputs/latest/metrics.json` (monitoreo operacional de una corrida).

## 5. Formatos de salida

Todos los archivos `.jsonl` tienen un JSON válido por línea y llevan `schema_version`, `run_id` y `model_version`.

**`predictions.jsonl`** (una línea por detección; cajas en píxeles de la imagen original):

```json
{"schema_version":"1.0","run_id":"20261009_101500_ab12cd34","prediction_id":"uuid","source_id":"video_001",
 "camera_id":"CAM_01","frame_id":128,"timestamp_seconds":4.27,"image_file":"frame_000128.jpg",
 "image_width":1280,"image_height":720,"model_version":"1.0.0","model_class":"person","class_name":"persona",
 "confidence":0.93,"bbox":{"x1":120,"y1":100,"x2":420,"y2":690},"track_id":15,"inside_roi":true,
 "zone_id":"AREA_OPERATIVA","violation_condition":"sin_casco","event_generated":true,
 "event_type":"persona_sin_casco","severity":"alta"}
```

**`events.jsonl`** (eventos consolidados): `event_id`, `event_type`, `severity`, `source_id`, `camera_id`,
`track_id`, `zone_id`, `start_frame_id`, `frame_id`, `start_timestamp_seconds`, `timestamp_seconds`,
`latency_seconds`, `persistence_frames`, `confidence`, `bbox`, `prediction_id` (enlaza con la predicción).

**`images_index.jsonl`** (una línea por imagen): estado (`ok`/`failed`), error, resolución, nº de detecciones,
tiempo de inferencia. Permite explicar imágenes sin detecciones y archivos fallidos.

**`metrics.json`** (monitoreo): `volume`, `performance`, `quality`, `segmentation`, `traceability`.

**`ground_truth.jsonl`**: registros `record_type: "image"` (definen el alcance revisado, incluso imágenes sin
objetos) y `record_type: "annotation"` (clase y caja). **`ground_truth_events.jsonl`**: eventos esperados.

## 6. Inferencia con imágenes de otra resolución

El modelo se entrenó a `imgsz=640`. Para imágenes de cualquier otro tamaño, `preprocessing.resize_mode` controla
la adaptación y **las cajas siempre se devuelven en coordenadas de la imagen original**:

| Modo | Qué hace | Cuándo usarlo |
|---|---|---|
| `letterbox` (defecto) | Reescala conservando la proporción y añade bordes grises hasta 640×640 | Casi siempre: no deforma personas ni EPP |
| `resize` | Estira a 640×640 | Sólo para comparar; distorsiona la proporción |
| `none` | No toca la imagen; Ultralytics aplica su letterbox interno | Línea base de comparación |

Para imágenes de muy alta resolución con EPP pequeños, sube `--imgsz` (p. ej. 960) o compara los tres modos
con las métricas del paso 5 y documenta el resultado en el reporte (sección 5.1).

## 7. Reglas de negocio (resumen)

| Condición | Evento | Severidad |
|---|---|---|
| Persona fuera del ROI | no genera evento | — |
| Persona sin chaleco | `persona_sin_chaleco` | media |
| Persona sin casco | `persona_sin_casco` | alta |
| Persona sin casco y sin chaleco | `persona_sin_casco_y_chaleco` | crítica |

Detalle (asociación por zonas del cuerpo, estrategias `association`/`explicit`/`hybrid`, persistencia temporal,
cooldown y fusión de cambios de `track_id`) en [`docs/DECISIONS.md`](docs/DECISIONS.md) y `configs/rules.yaml`.

**Modos de entrada:** `independent` (cada imagen es un caso aislado: sin tracking, persistencia de 1 frame) y
`sequence` (la carpeta es una secuencia ordenada de frames de una cámara: tracking IoU, persistencia
de 5 frames y 1 s por defecto). En `sequence`, cada subcarpeta se trata como una fuente (un «video»).

## 8. Reproducibilidad y trazabilidad

- Semillas fijadas en `configs/train.yaml` y `configs/inference.yaml` (`seed: 42`).
- `models/model_metadata.json`: arquitectura, pesos iniciales, huella (SHA-256) del dataset y del checkpoint,
  hiperparámetros, aumentos, hardware, tiempo, versiones y commit de git.
- Cada corrida de inferencia guarda `run_config.yaml` (configuración exacta + hash) e `inference.log`,
  y `metrics.json → traceability` incluye modelo, hash de configuración, fecha y semilla.
- El determinismo en GPU no es bit a bit: documenta variaciones entre ejecuciones en el reporte.

## 9. Entrega por correo

Sólo se acepta un archivo comprimido adjunto (sin enlaces a la nube ni `.py` sueltos):

```bash
python scripts/package_delivery.py --out entrega --max-mb 20            # sin dataset
python scripts/package_delivery.py --out entrega --max-mb 20 --include-data
```

Genera `entrega.zip` o `entrega_parte1deN.zip`, … con un `MANIFEST.txt` por parte. Identifica las partes en el asunto del correo.

## 10. Limitaciones conocidas

- Con imágenes aisladas no hay dimensión temporal: la persistencia vale 1 frame y no hay `track_id`.
- La verdad terreno de eventos derivada de las anotaciones (`--derive-events`) no sustituye una revisión humana.
- El ROI por defecto cubre toda la imagen; define polígonos reales en `configs/rules.yaml` para cada cámara.
- El dataset puede no representar las cámaras de producción (sesgo de dominio): ver `docs/DATASET.md`.
